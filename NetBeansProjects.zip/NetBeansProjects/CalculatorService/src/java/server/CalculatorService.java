/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="CalculatorService")

public class CalculatorService {

@WebMethod(operationName="add")

public int add(@WebParam(name="a") int a,
               @WebParam(name="b") int b){

return a+b;

}

@WebMethod(operationName="subtract")

public int subtract(@WebParam(name="a") int a,
                    @WebParam(name="b") int b){

return a-b;

}

}
