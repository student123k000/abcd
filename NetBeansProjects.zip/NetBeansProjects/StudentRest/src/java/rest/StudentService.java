package rest;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/student")

public class StudentService {

@GET

@Produces("text/plain")

public String getStudent(){

return "Student REST Service Running";

}

}