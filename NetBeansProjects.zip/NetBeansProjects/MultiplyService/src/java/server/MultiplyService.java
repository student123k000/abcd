/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="MultiplyService")

public class MultiplyService {

@WebMethod(operationName="multiply")

public int multiply(@WebParam(name="a") int a,
                    @WebParam(name="b") int b){

return a*b;

}

}