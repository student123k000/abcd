/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author shrut
 */
@WebService(serviceName = "TempService")
public class TempService {

public double FtoC(double f){

double c=(f-32)*5/9;

return c;

}

}
