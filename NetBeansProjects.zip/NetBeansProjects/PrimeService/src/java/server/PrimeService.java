/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="PrimeService")

public class PrimeService {

@WebMethod(operationName="checkPrime")

public String checkPrime(@WebParam(name="n") int n){

int flag = 0;

for(int i=2;i<n;i++){

if(n%i==0){

flag=1;
break;

}

}

if(flag==0)

return "Prime Number";

else

return "Not Prime";

}

}