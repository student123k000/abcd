/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author shrut
 */
@WebService(serviceName = "CurrencyService")
public class CurrencyService {

    /**
     * This is a sample web service operation
     */
public double rupeeToDollar(double r){

return r/90;

}

}