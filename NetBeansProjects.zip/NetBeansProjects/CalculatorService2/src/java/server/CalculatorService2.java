/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="CalculatorService2")

public class CalculatorService2 {

@WebMethod
public int multiply(int a,int b){

return a*b;

}

@WebMethod
public int divide(int a,int b){

return a/b;

}

}
