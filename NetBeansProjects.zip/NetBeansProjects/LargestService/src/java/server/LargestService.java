/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

@WebService(serviceName="LargestService")

public class LargestService {

@WebMethod
public int largest(int a,int b){

if(a>b)

return a;

else

return b;

}

}
